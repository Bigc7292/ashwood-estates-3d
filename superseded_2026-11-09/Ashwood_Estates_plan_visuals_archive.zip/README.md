# Ashwood Estates — Plan & Visuals Archive

See `reports/FINDINGS.md`, `missing/MISSING_ASSETS.md`, `reports/PROVENANCE.md`, `docs/USAGE.md`, and `docs/SYSTEM_PROMPT.md`.

**CAD-style images are source-based raster illustrations, not certified/native CAD.**
